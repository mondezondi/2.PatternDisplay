/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.patterndisplay;

/**
 *
 * @author Lenovo-User
 */
public class App {

    public static void main(String[] args) {
        int rows = 4;//Number of rows in the pattern
        int i =1;//Initializing row counter
        
        //Loop for each row
        while ( i<=rows){
            int j = 1;//initializing column counter
            
            //loop to print'*' based on row number
            while (j<=i){
                System.out.print("*");
                j++;
            }
            //Move to the next line after printing each row
            System.out.println();
            i++;
        }
    }
}
